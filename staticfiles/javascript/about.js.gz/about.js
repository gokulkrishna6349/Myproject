

$(document).ready(function(){
  $("#read").click(function(){
    $("#contact").toggle();
  });
});

